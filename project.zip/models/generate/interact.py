from transformers import AutoTokenizer, AutoModel
tokenizer = AutoTokenizer.from_pretrained("chatglm-6b", trust_remote_code=True)
model = AutoModel.from_pretrained("chatglm-6b", trust_remote_code=True).half().cuda()
history = []
while True:
    user_input = input('>>> user:')
    if user_input == '退出':
        break
    response, history = model.chat(tokenizer, user_input, history=[])
    print('>>> bot:',response)