import os
from elasticsearch import Elasticsearch
from models.search.preranking import PreRankingModel
from models.search.ranking import RankingModel

project_dir = '/root/Project/'
search_model_path = os.path.join(project_dir, 'models/search')
search_backbone = 'mc-bert'
backbone_dir = os.path.join(search_model_path, search_backbone)
index_name = 'MedQaData'

es_client = Elasticsearch("http://127.0.0.1:9200")
client.indices.delete(index=args.index_name, ignore=[404])

