import os
import warnings
warnings.filterwarnings("ignore")
import re
import json
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from transformers import BertTokenizer, AutoTokenizer, AutoModel
import torch
from torch.cuda.amp import autocast
from models.search.preranking import PreRankingModel
from models.search.ranking import RankingModel

project_dir = '/root/Project/'
# searching module
search_model_path = os.path.join(project_dir, 'models/search')
search_backbone = 'mc-bert'
backbone_dir = os.path.join(search_model_path, search_backbone)
index_name = 'med_qa_data'
search_thresold = 40
# generate module
generate_model_path = os.path.join(project_dir, 'models/generate')

def pre_ranking(query, encoder, num_candidates=128):
    # get sentence embedding
    tokenizer = BertTokenizer.from_pretrained(backbone_dir, local_files_only = True)
    encoded_input = tokenizer([query], max_length=100, padding='max_length', truncation=True, return_tensors='pt')
    input_ids = encoded_input['input_ids'].cuda()
    token_type_ids = encoded_input['token_type_ids'].cuda()
    attention_mask = encoded_input['attention_mask'].cuda()
    with autocast():
        query_vector = encoder(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask).pooler_output
    query_vector = query_vector.flatten().detach().cpu().numpy().tolist()
    # perform search
    es_client = Elasticsearch("http://127.0.0.1:9200")
    es_query = {
        "function_score":{
            "query": {
                "match": {"question": query}
            },
            "script_score": {
                "script": {
                    "source": "cosineSimilarity(params.query_vector, doc['text_vector']) + 1",
                    "params": {"query_vector": query_vector}
                }
            }
        }
    }
    response = es_client.search(
        index=index_name,
        body={
            "size": num_candidates,
            "query": es_query,
            "_source": {"includes": ["question", "answer"]}
            # "_source": {"includes": ["question", "answer", "text_vector"]}
        },
        explain=True
    )
    print(response['hits']['hits'][0])
    score = response['hits']['hits'][0]['_score']
    response = response['hits']['hits'][0]['_source']['answer']
    # prerank_results = [[response['_source']['question'], response['_source']['answer'], response['_score'], ] for response in responses['hits']['hits']]
    return response, score

def generate_response(query, model):
    tokenizer = AutoTokenizer.from_pretrained(os.path.join(generate_model_path, 'chatglm-6b'), trust_remote_code=True)
    response, _ = model.chat(tokenizer, query, history=[])
    return response

if __name__ == '__main__':
    # load preranking model
    print('loading preranking model...')
    pre_ranking_model = PreRankingModel(backbone_dir=backbone_dir).cuda()
    # pre_ranking_model.load_state_dict(torch.load(os.path.join(search_model_path, 'preranking-reg-combined.bin')))
    # pre_ranking_model.load_state_dict(torch.load(os.path.join(search_model_path, 'preranking-reg-qqr.bin')))
    pre_ranking_model.load_state_dict(torch.load(os.path.join(search_model_path, 'preranking_fn.bin')))
    pre_ranking_model.eval()
    query_encoder = pre_ranking_model.encoder1
    # load generative model
    print('loading generative model...')
    generative_model = AutoModel.from_pretrained(os.path.join(generate_model_path, 'chatglm-6b'), trust_remote_code=True).half().cuda()
    # interact
    print('preparation done')
    while True:
        query = input('\033[1;31mUser:\033[0m')
        if query == '退出':
            break
        # perform search
        print('小助手正在思考...')
        response, score = pre_ranking(query, query_encoder)
        if score < search_thresold:
            # similar question not found, generate
            response = generate_response(query, generative_model)
            response = re.sub('ChatGLM-6B', 'MedBot', response)
            print('\033[1;31mBot[generate]:\033[0m', response)
        else:
            # similar question found, print answer in database
            print('\033[1;31mBot[search]:\033[0m', response)